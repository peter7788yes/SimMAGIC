using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.Utility;
using Hamastar.SimMAGIC.Utility.BackgroundLoading;
using Main.Hamastar.SimMAGIC.AutoLibary;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;

namespace Hamastar.SimMAGIC.Main
{
	public class SaveProject
	{
		public EventHandler SaveProjectCompleted;

		[CompilerGenerated]
		private bool _003CIsSuccessed_003Ek__BackingField;

		[CompilerGenerated]
		private bool _003CSaveAs_003Ek__BackingField;

		public bool IsSuccessed
		{
			[CompilerGenerated]
			get
			{
				return _003CIsSuccessed_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CIsSuccessed_003Ek__BackingField = value;
			}
		}

		public bool SaveAs
		{
			[CompilerGenerated]
			get
			{
				return _003CSaveAs_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CSaveAs_003Ek__BackingField = value;
			}
		}

		public void Start()
		{
			if (SaveAs || string.IsNullOrEmpty(GlobalResource.SaveSdPath))
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.OverwritePrompt = false;
				saveFileDialog.Filter = "SD Files(*.sd)|*.sd";
				SaveFileDialog sfd = saveFileDialog;
				if (Singleton.Instance.DefaultProject.ProjectMetadata.Name != "")
				{
					sfd.FileName = Singleton.Instance.DefaultProject.ProjectMetadata.Name + "ED";
				}
				else
				{
					sfd.FileName = GlobalResource.GetString("教材") + GlobalResource.ProjectCountNum + "ED";
				}
				Nullable<bool> flag = sfd.ShowDialog();
				if (!flag.GetValueOrDefault() || !flag.HasValue)
				{
					return;
				}
				string sdPath = sfd.FileName;
				if (File.Exists(sdPath))
				{
					string message2 = GlobalResource.GetString("檔案已存在是否要覆寫？（請注意：覆寫檔案會清空匯出資料夾和所有檔案）").Replace("\\r\\n", "\r\n");
					if (MessageBoxResult.No == MessageBox.Show(message2, GlobalResource.MsgTitle, MessageBoxButton.YesNo, MessageBoxImage.Question))
					{
						return;
					}
				}
				else
				{
					sdPath = Path.Combine(Path.ChangeExtension(sfd.FileName, null), Path.GetFileName(sfd.FileName));
					if (File.Exists(sdPath))
					{
						string message = GlobalResource.GetString("檔案已存在是否要覆寫？（請注意：覆寫檔案會清空匯出資料夾和所有檔案）").Replace("\\r\\n", "\r\n");
						if (MessageBoxResult.No == MessageBox.Show(message, GlobalResource.MsgTitle, MessageBoxButton.YesNo, MessageBoxImage.Question))
						{
							return;
						}
					}
				}
				RunWorker(sdPath);
			}
			else
			{
				RunWorker(GlobalResource.SaveSdPath);
			}
		}

		private void RunWorker(string sdPath)
		{
			Dictionary<string, object> doWorkPara = new Dictionary<string, object>();
			doWorkPara.Add("sdPath", sdPath);
			IsSuccessed = false;
			BgWorkerView.RunWorker(new Action<Dictionary<string, object>>(ArchiveProject), null, doWorkPara, false);
			if (IsSuccessed)
			{
				MessageBox.Show(GlobalResource.GetString("儲存成功"), GlobalResource.MsgTitle, MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			if (SaveProjectCompleted != null)
			{
				SaveProjectCompleted(Path.GetFileNameWithoutExtension(sdPath), null);
				if (Singleton.Instance.ProfileService.RecentOpenProfile.Projects.Count >= 8)
				{
					Singleton.Instance.ProfileService.RecentOpenProfile.Projects.RemoveAt(0);
				}
				Singleton.Instance.ProfileService.RecentOpenProfile.Projects.Add(sdPath);
			}
		}

		private void ArchiveProject(Dictionary<string, object> dic)
		{
			GlobalResource.IsSaving = true;
			BgWorkerView.ReportProgress(GlobalResource.GetString("處理中") + "...");
			string sdPath = dic["sdPath"].ToString();
			string ExportDirectory = Path.GetDirectoryName(sdPath);
			string ExportFilename = Path.GetFileNameWithoutExtension(sdPath);
			ProjectController projectController = new ProjectController(ExportDirectory, ExportFilename);
			projectController.IsSaveSd = true;
			IsSuccessed = projectController.ExportEbook();
			if (IsSuccessed)
			{
				GlobalResource.ProjectCountNum++;
				GlobalResource.SaveSdPath = sdPath;
			}
			GlobalResource.IsSaving = false;
		}
	}
}
