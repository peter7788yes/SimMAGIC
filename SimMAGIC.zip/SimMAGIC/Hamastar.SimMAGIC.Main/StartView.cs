using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.SectionMetadata;
using Hamastar.SimMAGIC.Utility;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Xml.Linq;

namespace Hamastar.SimMAGIC.Main
{
	public class StartView : UserControl, IComponentConnector
	{
		public EventHandler SwitchToMainView;

		public EventHandler NewProjectEvent;

		internal TextBlock ProductName;

		internal TextBlock ProductVersion;

		public Button CloseBtn;

		public Button MinBtn;

		internal Grid OptionGrid;

		internal Grid NewProject;

		internal TextBlock NewProjectTbk;

		internal TextBlock MotherboardEditorTbk;

		internal TextBlock Tutorial;

		internal TextBlock OpenProjectTbk;

		internal StackPanel TemplateProjectSp;

		internal TextBlock TemplateProject;

		internal StackPanel RecentOpenProjectSp;

		internal TextBlock RecentOpenProject;

		private bool _contentLoaded;

		[CompilerGenerated]
		private static Func<XElement, XElement> CS_0024_003C_003E9__CachedAnonymousMethodDelegate1;

		public StartView()
		{
			InitializeComponent();
			base.Loaded += new RoutedEventHandler(StartView_Loaded);
			ProductVersion.Text = GlobalResource.GetEditorVersion();
		}

		private void StartView_Loaded(object sender, RoutedEventArgs e)
		{
			ProductName.Text = GlobalResource.GetString("互動式多媒體電子書編輯軟體");
			NewProjectTbk.Text = GlobalResource.GetString("新增電子書");
			MotherboardEditorTbk.Text = GlobalResource.GetString("版型編輯器");
			Tutorial.Text = GlobalResource.GetString("新手上路");
			OpenProjectTbk.Text = GlobalResource.GetString("開啟舊檔");
			TemplateProject.Text = GlobalResource.GetString("電子書範本");
			RecentOpenProject.Text = GlobalResource.GetString("最近編輯電子書");
			LoadDemoCourse();
			LoadRecentOpenProjects();
		}

		public void LoadRecentOpenProjects()
		{
			List<string> projects = Singleton.Instance.ProfileService.RecentOpenProfile.Projects;
			RecentOpenProjectSp.Children.Clear();
			for (int index = 0; index < 8 && index + 1 <= projects.Count; index++)
			{
				string project = projects[index];
				TextBlock txt = new TextBlock();
				txt.Style = (OptionGrid.Resources["HyperLinkTbStyle"] as Style);
				txt.Text = "》" + Path.GetFileNameWithoutExtension(project);
				txt.Tag = project;
				txt.MouseLeftButtonDown += new MouseButtonEventHandler(RecentOpenProject_OnMouseLeftButtonDown);
				RecentOpenProjectSp.Children.Add(txt);
			}
		}

		private void RecentOpenProject_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			string sdPath = ((TextBlock)sender).Tag.ToString();
			if (File.Exists(sdPath))
			{
				OpenProject openProject = new OpenProject();
				openProject.OpenProjectCompleted = (EventHandler)Delegate.Combine(openProject.OpenProjectCompleted, new EventHandler(OpenProjectCompleted));
				openProject.Start(sdPath);
			}
			else
			{
				Singleton.Instance.ProfileService.RecentOpenProfile.Projects.Remove(sdPath);
				Singleton.Instance.ProfileService.SaveToXml();
				LoadRecentOpenProjects();
			}
		}

		private void LoadDemoCourse()
		{
			TemplateProjectSp.Children.Clear();
			if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\DemoCourseName.xml"))
			{
				return;
			}
			XDocument demoCourseName = XDocument.Load(AppDomain.CurrentDomain.BaseDirectory + "\\DemoCourseName.xml");
			IEnumerable<XElement> source = Extensions.Elements(demoCourseName.Elements("data"), "course");
			if (CS_0024_003C_003E9__CachedAnonymousMethodDelegate1 == null)
			{
				CS_0024_003C_003E9__CachedAnonymousMethodDelegate1 = new Func<XElement, XElement>(_003CLoadDemoCourse_003Eb__0);
			}
			IEnumerable<XElement> pets = Enumerable.Select(source, CS_0024_003C_003E9__CachedAnonymousMethodDelegate1);
			foreach (XElement element in pets)
			{
				string projectName = Path.GetFileNameWithoutExtension(element.Value);
				if (projectName == GlobalResource.GetString("魔幻效果範本") || projectName == GlobalResource.GetString("電子型錄") || projectName == GlobalResource.GetString("範例教材"))
				{
					TextBlock txt = new TextBlock();
					txt.Style = (OptionGrid.Resources["HyperLinkTbStyle"] as Style);
					txt.Text = "》" + projectName;
					txt.Tag = AppDomain.CurrentDomain.BaseDirectory + element.Value;
					txt.MouseLeftButtonDown += new MouseButtonEventHandler(TemplateProject_OnMouseLeftButtonDown);
					TemplateProjectSp.Children.Add(txt);
				}
			}
		}

		private void TemplateProject_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			string sdPath = ((TextBlock)sender).Tag.ToString();
			OpenProject openProject = new OpenProject();
			openProject.OpenProjectCompleted = (EventHandler)Delegate.Combine(openProject.OpenProjectCompleted, new EventHandler(OpenProjectCompleted));
			openProject.NoSaveSdPath = true;
			openProject.Start(sdPath);
		}

		private void NewProject_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (SwitchToMainView != null)
			{
				EventHandler switchToMainView = SwitchToMainView;
				SwitchEventArgs switchEventArgs = new SwitchEventArgs();
				switchEventArgs.SelectIdx = 0;
				switchToMainView(this, switchEventArgs);
			}
		}

		private void MotherboardEditor_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			CustomiseMotherBoardEditorDialog dlg = new CustomiseMotherBoardEditorDialog();
			Nullable<bool> flag = dlg.ShowDialog();
			if (flag.GetValueOrDefault() && flag.HasValue)
			{
				Button button = new Button();
				button.Content = dlg.WDoubleUpDown.Value + "x" + dlg.HDoubleUpDown.Value;
				button.Width = 120.0;
				button.Height = 120.0;
				button.Tag = "C";
				button.Cursor = Cursors.Hand;
				Button btn = button;
				NewBookInfoEventArgs eventArgs = new NewBookInfoEventArgs();
				string[] data = btn.Content.ToString().Split('x');
				eventArgs.Size = new Size(int.Parse(data[0]), int.Parse(data[1]));
				if (SwitchToMainView != null)
				{
					EventHandler switchToMainView = SwitchToMainView;
					SwitchEventArgs switchEventArgs = new SwitchEventArgs();
					switchEventArgs.SelectIdx = 1;
					switchEventArgs.CustomiseMotherBoardSize = eventArgs;
					switchToMainView(this, switchEventArgs);
				}
			}
		}

		private void Tutorial_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			string videoUrl = string.Format(GlobalResource.VideoTutorial, GlobalResource.GetString("視訊教學Url語系"));
			Process.Start(videoUrl);
		}

		private void OpenProject_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			OpenProject openProject = new OpenProject();
			openProject.OpenProjectCompleted = (EventHandler)Delegate.Combine(openProject.OpenProjectCompleted, new EventHandler(OpenProjectCompleted));
			openProject.Start(null);
		}

		private void OpenProjectCompleted(object sender, EventArgs args)
		{
			if ((sender as OpenProject).IsSuccessed && SwitchToMainView != null)
			{
				EventHandler switchToMainView = SwitchToMainView;
				SwitchEventArgs switchEventArgs = new SwitchEventArgs();
				switchEventArgs.SelectIdx = 1;
				switchToMainView(this, switchEventArgs);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/usercontrol/startview.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				ProductName = (TextBlock)target;
				break;
			case 2:
				ProductVersion = (TextBlock)target;
				break;
			case 3:
				CloseBtn = (Button)target;
				break;
			case 4:
				MinBtn = (Button)target;
				break;
			case 5:
				OptionGrid = (Grid)target;
				break;
			case 6:
				NewProject = (Grid)target;
				NewProject.MouseLeftButtonDown += new MouseButtonEventHandler(NewProject_OnMouseLeftButtonDown);
				break;
			case 7:
				NewProjectTbk = (TextBlock)target;
				break;
			case 8:
				((Grid)target).MouseLeftButtonDown += new MouseButtonEventHandler(MotherboardEditor_OnMouseLeftButtonDown);
				break;
			case 9:
				MotherboardEditorTbk = (TextBlock)target;
				break;
			case 10:
				((Grid)target).MouseLeftButtonDown += new MouseButtonEventHandler(Tutorial_OnMouseLeftButtonDown);
				break;
			case 11:
				Tutorial = (TextBlock)target;
				break;
			case 12:
				((Grid)target).MouseLeftButtonDown += new MouseButtonEventHandler(OpenProject_OnMouseLeftButtonDown);
				break;
			case 13:
				OpenProjectTbk = (TextBlock)target;
				break;
			case 14:
				TemplateProjectSp = (StackPanel)target;
				break;
			case 15:
				TemplateProject = (TextBlock)target;
				break;
			case 16:
				RecentOpenProjectSp = (StackPanel)target;
				break;
			case 17:
				RecentOpenProject = (TextBlock)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[CompilerGenerated]
		private static XElement _003CLoadDemoCourse_003Eb__0(XElement pet)
		{
			return pet;
		}
	}
}
