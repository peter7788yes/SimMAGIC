using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.SectionDesign;
using Hamastar.SimMAGIC.Utility;
using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using Xceed.Wpf.Toolkit;

namespace Hamastar.SimMAGIC.Main
{
	public class OptionProfileDialog : Window, IComponentConnector
	{
		internal System.Windows.Controls.TextBox ExportFullFolder;

		internal System.Windows.Controls.TextBox BgMusicFilePath;

		internal MusicTestView MusicTest;

		internal System.Windows.Controls.TextBox PageTurnFilePath;

		internal System.Windows.Controls.ComboBox ErrorCountCb;

		internal System.Windows.Controls.CheckBox CustomNextCb;

		internal IntegerUpDown IntervalSec;

		internal System.Windows.Controls.ComboBox PDFDpiCb;

		internal System.Windows.Controls.ComboBox PPTDpiCb;

		internal System.Windows.Controls.CheckBox VideoAutoPlayCb;

		private bool _contentLoaded;

		[CompilerGenerated]
		private static Func<System.Windows.Controls.Label, bool> CS_0024_003C_003E9__CachedAnonymousMethodDelegate2;

		[CompilerGenerated]
		private static Func<System.Windows.Controls.Label, bool> CS_0024_003C_003E9__CachedAnonymousMethodDelegate3;

		public OptionProfileDialog()
		{
			InitializeComponent();
			Init();
			base.Closed += new EventHandler(OptionProfileDialog_Closed);
		}

		private void OptionProfileDialog_Closed(object sender, EventArgs e)
		{
			MusicTest.Dispose();
		}

		private void Init()
		{
			ExportFullFolder.Text = Singleton.Instance.ProfileService.OptionProfile.WorkDirectory;
			System.Windows.Controls.ComboBox pDFDpiCb = PDFDpiCb;
			IEnumerable<System.Windows.Controls.Label> source = Enumerable.OfType<System.Windows.Controls.Label>(PDFDpiCb.Items);
			if (CS_0024_003C_003E9__CachedAnonymousMethodDelegate2 == null)
			{
				CS_0024_003C_003E9__CachedAnonymousMethodDelegate2 = new Func<System.Windows.Controls.Label, bool>(_003CInit_003Eb__0);
			}
			pDFDpiCb.SelectedItem = Enumerable.FirstOrDefault(source, CS_0024_003C_003E9__CachedAnonymousMethodDelegate2);
			System.Windows.Controls.ComboBox pPTDpiCb = PPTDpiCb;
			IEnumerable<System.Windows.Controls.Label> source2 = Enumerable.OfType<System.Windows.Controls.Label>(PPTDpiCb.Items);
			if (CS_0024_003C_003E9__CachedAnonymousMethodDelegate3 == null)
			{
				CS_0024_003C_003E9__CachedAnonymousMethodDelegate3 = new Func<System.Windows.Controls.Label, bool>(_003CInit_003Eb__1);
			}
			pPTDpiCb.SelectedItem = Enumerable.FirstOrDefault(source2, CS_0024_003C_003E9__CachedAnonymousMethodDelegate3);
			IntervalSec.Value = Singleton.Instance.DefaultProject.DefaultProcedureSliceIntervalWaitSeconds;
			VideoAutoPlayCb.IsChecked = Singleton.Instance.DefaultProject.VideoAutoPlay;
			CustomNextCb.IsChecked = Singleton.Instance.DefaultProject.NextPageSet;
			CustomNextCb.Checked -= new RoutedEventHandler(CustomNextCb_Checked);
			CustomNextCb.Unchecked -= new RoutedEventHandler(CustomNextCb_Unchecked);
			CustomNextCb.Checked += new RoutedEventHandler(CustomNextCb_Checked);
			CustomNextCb.Unchecked += new RoutedEventHandler(CustomNextCb_Unchecked);
			BgMusicFilePath.Text = Singleton.Instance.DefaultProject.BackgroundMusicFileName;
			MusicTest.Volume = Singleton.Instance.DefaultProject.BackgroundMusicVolume;
			ErrorCountCb.SelectedIndex = Singleton.Instance.DefaultProject.ErrorCount - 1;
			PageTurnFilePath.Text = Singleton.Instance.DefaultProject.PageTurnFileName;
		}

		private void OKButtonBase_OnClick(object sender, RoutedEventArgs e)
		{
			Singleton.Instance.ProfileService.OptionProfile.WorkDirectory = ExportFullFolder.Text;
			Singleton.Instance.DefaultProject.BackgroundMusicFileName = BgMusicFilePath.Text;
			Singleton.Instance.DefaultProject.BackgroundMusicVolume = MusicTest.Volume;
			Singleton.Instance.DefaultProject.ErrorCount = ((ErrorCountCb.SelectedIndex + 1 > 8) ? int.MaxValue : (ErrorCountCb.SelectedIndex + 1));
			Singleton.Instance.DefaultProject.PageTurnFileName = PageTurnFilePath.Text;
			int ii;
			if (int.TryParse(IntervalSec.Value.ToString(), out ii))
			{
				Singleton.Instance.DefaultProject.DefaultProcedureSliceIntervalWaitSeconds = ii;
			}
			Singleton.Instance.ProfileService.OptionProfile.PDFDpi = int.Parse((PDFDpiCb.SelectedItem as System.Windows.Controls.Label).Content.ToString());
			Singleton.Instance.ProfileService.OptionProfile.PPTDpi = int.Parse((PPTDpiCb.SelectedItem as System.Windows.Controls.Label).Content.ToString());
			DefaultProject defaultProject = Singleton.Instance.DefaultProject;
			Nullable<bool> isChecked = VideoAutoPlayCb.IsChecked;
			defaultProject.VideoAutoPlay = (isChecked.GetValueOrDefault() && isChecked.HasValue);
			DefaultProject defaultProject2 = Singleton.Instance.DefaultProject;
			Nullable<bool> isChecked2 = CustomNextCb.IsChecked;
			defaultProject2.NextPageSet = (isChecked2.GetValueOrDefault() && isChecked2.HasValue);
			SetAllSlice();
			Singleton.Instance.ProfileService.SaveToXml();
			base.DialogResult = true;
		}

		private void SetAllSlice()
		{
			foreach (ProcedureSlice slice in Singleton.Instance.DefaultProject.ProcedureSliceList)
			{
				slice.BackgroundMusicVolume = MusicTest.Volume;
				slice.IntervalSeconds = IntervalSec.Value.Value;
				SetAllVideoAutoPlay(slice);
			}
		}

		private void SetAllVideoAutoPlay(ProcedureSlice slice)
		{
			foreach (WhiteboardObject wObj in slice.WhiteboardObjectList)
			{
				VideoObject videoObj = wObj as VideoObject;
				if (videoObj != null)
				{
					Nullable<bool> isChecked = VideoAutoPlayCb.IsChecked;
					videoObj.AutoPlay = (isChecked.GetValueOrDefault() && isChecked.HasValue);
				}
				IntroductionObject introObj = wObj as IntroductionObject;
				if (introObj == null)
				{
					continue;
				}
				foreach (WhiteboardObject IntroVideo in introObj.WobjectList)
				{
					VideoObject IntroVideoObj = IntroVideo as VideoObject;
					if (IntroVideoObj != null)
					{
						Nullable<bool> isChecked2 = VideoAutoPlayCb.IsChecked;
						IntroVideoObj.AutoPlay = (isChecked2.GetValueOrDefault() && isChecked2.HasValue);
					}
				}
			}
		}

		private void ExportFullFolderButtonBase_OnClick(object sender, RoutedEventArgs e)
		{
			FolderBrowserDialog folderDig = new FolderBrowserDialog();
			folderDig.SelectedPath = ExportFullFolder.Text;
			folderDig.ShowNewFolderButton = true;
			if (folderDig.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				ExportFullFolder.Text = folderDig.SelectedPath;
			}
		}

		private void BgMusicPathButtonBase_OnClick(object sender, RoutedEventArgs e)
		{
			Microsoft.Win32.OpenFileDialog fdlg = new Microsoft.Win32.OpenFileDialog();
			fdlg.FileName = BgMusicFilePath.Text;
			fdlg.Filter = "Sound Files(*.wav;*.wma;*.mp3)|*.wav;*.wma;*.mp3";
			Nullable<bool> flag = fdlg.ShowDialog();
			if (flag.GetValueOrDefault() && flag.HasValue)
			{
				BgMusicFilePath.Text = fdlg.FileName;
			}
		}

		private void BgMusicFilePath_OnTextChanged(object sender, TextChangedEventArgs e)
		{
			MusicTest.BgMusicPath = BgMusicFilePath.Text;
		}

		private void ResetButtonBase_OnClick(object sender, RoutedEventArgs e)
		{
			Singleton.Instance.ProfileService.Reset();
			Init();
			DefaultProject ProjectReset = new DefaultProject();
			IntervalSec.Value = ProjectReset.DefaultProcedureSliceIntervalWaitSeconds;
			VideoAutoPlayCb.IsChecked = ProjectReset.VideoAutoPlay;
			BgMusicFilePath.Text = ProjectReset.BackgroundMusicFileName;
			MusicTest.Volume = ProjectReset.BackgroundMusicVolume;
			ErrorCountCb.SelectedIndex = ProjectReset.ErrorCount - 1;
			PageTurnFilePath.Text = ProjectReset.PageTurnFileName;
			CustomNextCb.IsChecked = ProjectReset.NextPageSet;
		}

		private void CorrectErrorMsgButton_OnClick(object sender, RoutedEventArgs e)
		{
			CorrectErrorMessageDialog dlg = new CorrectErrorMessageDialog();
			dlg.ForCorrectSet = ((sender as System.Windows.Controls.Button).Tag.ToString() == "Correct");
			dlg.Init(Singleton.Instance.DefaultProject.CeMessageInfo);
			Nullable<bool> flag = dlg.ShowDialog();
			if (flag.GetValueOrDefault() && flag.HasValue)
			{
				Singleton.Instance.DefaultProject.CeMessageInfo = dlg.MsgInfo;
				for (int index = 0; index < Singleton.Instance.DefaultProject.ProcedureSliceList.Count; index++)
				{
					ProcedureSlice slice = Singleton.Instance.DefaultProject.ProcedureSliceList[index];
					slice.CeMessageInfo = dlg.MsgInfo;
					Dictionary<string, object> dic = new Dictionary<string, object>();
					dic.Add("CurrentSliceIndex", index);
					NotificationCenter.defaultCenter.postNotification(this, "CorrectErrorMessageSet", dic);
				}
			}
		}

		private void PageTurn_OnClick(object sender, RoutedEventArgs e)
		{
			using (CustomOpenFieDialog psd = new CustomOpenFieDialog(MaterialType.Sound))
			{
				psd.Multiselect = false;
				psd.SelectedFilePath = PageTurnFilePath.Text;
				Nullable<bool> flag = psd.ShowDialog();
				if (flag.GetValueOrDefault() && flag.HasValue)
				{
					PageTurnFilePath.Text = psd.SelectedFilePath;
				}
			}
		}

		private void CustomNextCb_Checked(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.CheckBox checkBox = sender as System.Windows.Controls.CheckBox;
			if (checkBox == null)
			{
				return;
			}
			checkBox.Checked -= new RoutedEventHandler(CustomNextCb_Checked);
			for (int index = 0; index < Singleton.Instance.DefaultProject.ProcedureSliceList.Count; index++)
			{
				ProcedureSlice slice = Singleton.Instance.DefaultProject.ProcedureSliceList[index];
				slice.CustomNextSet = true;
				if (index + 1 <= Singleton.Instance.DefaultProject.ProcedureSliceList.Count - 1)
				{
					slice.CustomNextProcedureSliceIndex = Singleton.Instance.DefaultProject.ProcedureSliceList[index + 1].SliceIdentifier;
				}
				else
				{
					slice.CustomNextProcedureSliceIndex = Guid.Empty;
				}
			}
			Singleton.Instance.DefaultProject.NextPageSet = true;
		}

		private void CustomNextCb_Unchecked(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.CheckBox checkBox = sender as System.Windows.Controls.CheckBox;
			if (checkBox != null)
			{
				checkBox.Unchecked -= new RoutedEventHandler(CustomNextCb_Unchecked);
				for (int index = 0; index < Singleton.Instance.DefaultProject.ProcedureSliceList.Count; index++)
				{
					ProcedureSlice slice = Singleton.Instance.DefaultProject.ProcedureSliceList[index];
					slice.CustomNextSet = true;
					slice.CustomNextProcedureSliceIndex = Guid.Empty;
				}
				Singleton.Instance.DefaultProject.NextPageSet = false;
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/usercontrol/optionprofiledialog.xaml", UriKind.Relative);
				System.Windows.Application.LoadComponent(this, resourceLocater);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				ExportFullFolder = (System.Windows.Controls.TextBox)target;
				break;
			case 2:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(ExportFullFolderButtonBase_OnClick);
				break;
			case 3:
				BgMusicFilePath = (System.Windows.Controls.TextBox)target;
				BgMusicFilePath.TextChanged += new TextChangedEventHandler(BgMusicFilePath_OnTextChanged);
				break;
			case 4:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(BgMusicPathButtonBase_OnClick);
				break;
			case 5:
				MusicTest = (MusicTestView)target;
				break;
			case 6:
				PageTurnFilePath = (System.Windows.Controls.TextBox)target;
				break;
			case 7:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(PageTurn_OnClick);
				break;
			case 8:
				ErrorCountCb = (System.Windows.Controls.ComboBox)target;
				break;
			case 9:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(CorrectErrorMsgButton_OnClick);
				break;
			case 10:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(CorrectErrorMsgButton_OnClick);
				break;
			case 11:
				CustomNextCb = (System.Windows.Controls.CheckBox)target;
				break;
			case 12:
				IntervalSec = (IntegerUpDown)target;
				break;
			case 13:
				PDFDpiCb = (System.Windows.Controls.ComboBox)target;
				break;
			case 14:
				PPTDpiCb = (System.Windows.Controls.ComboBox)target;
				break;
			case 15:
				VideoAutoPlayCb = (System.Windows.Controls.CheckBox)target;
				break;
			case 16:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(OKButtonBase_OnClick);
				break;
			case 17:
				((System.Windows.Controls.Button)target).Click += new RoutedEventHandler(ResetButtonBase_OnClick);
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[CompilerGenerated]
		private static bool _003CInit_003Eb__0(System.Windows.Controls.Label item)
		{
			return int.Parse(item.Content.ToString()) == Singleton.Instance.ProfileService.OptionProfile.PDFDpi;
		}

		[CompilerGenerated]
		private static bool _003CInit_003Eb__1(System.Windows.Controls.Label item)
		{
			return int.Parse(item.Content.ToString()) == Singleton.Instance.ProfileService.OptionProfile.PPTDpi;
		}
	}
}
