using Hamastar.SimMAGIC.Utility;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;

namespace Hamastar.SimMAGIC.Main
{
	public class MainWindow : Window, IComponentConnector
	{
		private StartView _startView = new StartView();

		private MainView _mainView = new MainView();

		private bool _contentLoaded;

		public MainWindow()
		{
			InitializeComponent();
			SetStartView();
			GlobalResource.OwnerWindow = this;
			base.LocationChanged += new EventHandler(MainWindow_LocationChanged);
			base.Closing += new CancelEventHandler(MainWindow_Closing);
		}

		private void MainWindow_Closing(object sender, CancelEventArgs e)
		{
			if (AskCloseOrNot())
			{
				if (base.Content is MainView && !_mainView.AskSaveAsProject())
				{
					e.Cancel = true;
				}
			}
			else
			{
				e.Cancel = true;
			}
		}

		private void MainWindow_LocationChanged(object sender, EventArgs e)
		{
			if (base.Content is StartView)
			{
				CenterWindowOnScreen(_startView);
			}
		}

		public void SetStartView()
		{
			_startView.MinBtn.Click -= new RoutedEventHandler(MinBtn_OnClick);
			_startView.MinBtn.Click += new RoutedEventHandler(MinBtn_OnClick);
			_startView.CloseBtn.Click -= new RoutedEventHandler(CloseBtn_OnClick);
			_startView.CloseBtn.Click += new RoutedEventHandler(CloseBtn_OnClick);
			StartView startView = _startView;
			startView.SwitchToMainView = (EventHandler)Delegate.Remove(startView.SwitchToMainView, new EventHandler(StartView_SwitchToMainView));
			StartView startView2 = _startView;
			startView2.SwitchToMainView = (EventHandler)Delegate.Combine(startView2.SwitchToMainView, new EventHandler(StartView_SwitchToMainView));
			base.WindowState = WindowState.Minimized;
			base.Content = _startView;
			base.SizeToContent = SizeToContent.WidthAndHeight;
			base.ResizeMode = ResizeMode.NoResize;
			base.WindowStyle = WindowStyle.None;
			base.WindowState = WindowState.Normal;
		}

		private void SetMainView()
		{
			base.WindowState = WindowState.Minimized;
			base.Content = _mainView;
			base.SizeToContent = SizeToContent.Manual;
			base.ResizeMode = ResizeMode.CanResize;
			base.WindowStyle = WindowStyle.SingleBorderWindow;
			base.WindowState = WindowState.Maximized;
		}

		private void CenterWindowOnScreen(UserControl userControl)
		{
			double screenWidth = SystemParameters.PrimaryScreenWidth;
			double screenHeight = SystemParameters.PrimaryScreenHeight;
			double windowWidth = userControl.Width;
			double windowHeight = userControl.Height;
			base.Left = screenWidth / 2.0 - windowWidth / 2.0;
			base.Top = screenHeight / 2.0 - windowHeight / 2.0;
		}

		private void window_Activated(object sender, EventArgs e)
		{
			base.Activated -= new EventHandler(window_Activated);
			Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(_003Cwindow_Activated_003Eb__0));
		}

		private void MinBtn_OnClick(object sender, RoutedEventArgs e)
		{
			base.Activated += new EventHandler(window_Activated);
			base.WindowStyle = WindowStyle.SingleBorderWindow;
			base.WindowState = WindowState.Minimized;
		}

		private void CloseBtn_OnClick(object sender, RoutedEventArgs e)
		{
			Close();
		}

		private void StartView_SwitchToMainView(object sender, EventArgs args)
		{
			SetMainView();
			SwitchEventArgs switchEventArgs = args as SwitchEventArgs;
			if (switchEventArgs.CustomiseMotherBoardSize != null)
			{
				_mainView.tabControl.SelectedIndex = 0;
				_mainView.NewProjectEvent(null, switchEventArgs.CustomiseMotherBoardSize);
			}
			else
			{
				_mainView.tabControl.SelectedIndex = switchEventArgs.SelectIdx;
			}
		}

		private bool AskCloseOrNot()
		{
			bool close = false;
			MessageBoxResult result = MessageBox.Show(GlobalResource.GetString("是否要關閉?"), GlobalResource.MsgTitle, MessageBoxButton.YesNo, MessageBoxImage.Question);
			if (result == MessageBoxResult.Yes)
			{
				close = true;
			}
			return close;
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/mainwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			_contentLoaded = true;
		}

		[CompilerGenerated]
		private void _003Cwindow_Activated_003Eb__0()
		{
			base.WindowStyle = WindowStyle.None;
		}
	}
}
