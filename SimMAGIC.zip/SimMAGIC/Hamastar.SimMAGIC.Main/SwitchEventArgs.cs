using System;
using System.Runtime.CompilerServices;

namespace Hamastar.SimMAGIC.Main
{
	public class SwitchEventArgs : EventArgs
	{
		[CompilerGenerated]
		private int _003CSelectIdx_003Ek__BackingField;

		[CompilerGenerated]
		private EventArgs _003CCustomiseMotherBoardSize_003Ek__BackingField;

		public int SelectIdx
		{
			[CompilerGenerated]
			get
			{
				return _003CSelectIdx_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CSelectIdx_003Ek__BackingField = value;
			}
		}

		public EventArgs CustomiseMotherBoardSize
		{
			[CompilerGenerated]
			get
			{
				return _003CCustomiseMotherBoardSize_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CCustomiseMotherBoardSize_003Ek__BackingField = value;
			}
		}
	}
}
