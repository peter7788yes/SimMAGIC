using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace Hamastar.SimMAGIC.Main
{
	public class BackgroundTabView : UserControl, IComponentConnector
	{
		public Border Root;

		private bool _contentLoaded;

		public BackgroundTabView()
		{
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/usercontrol/backgroundtabview.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				Root = (Border)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
}
