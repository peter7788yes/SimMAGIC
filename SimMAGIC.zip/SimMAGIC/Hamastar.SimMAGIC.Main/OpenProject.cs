using Hamastar.IO;
using Hamastar.SevenZipSharp;
using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.Utility;
using Hamastar.SimMAGIC.Utility.BackgroundLoading;
using Main.Hamastar.SimMAGIC.AutoLibary;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Xml.Linq;

namespace Hamastar.SimMAGIC.Main
{
	public class OpenProject
	{
		public EventHandler OpenProjectCompleted;

		private int slicepage = -1;

		[CompilerGenerated]
		private bool _003CNoSaveSdPath_003Ek__BackingField;

		[CompilerGenerated]
		private bool _003CIsSuccessed_003Ek__BackingField;

		[CompilerGenerated]
		private ProcedureSlice _003CSlice_003Ek__BackingField;

		[CompilerGenerated]
		private static Func<FileInfo, bool> CS_0024_003C_003E9__CachedAnonymousMethodDelegate2;

		public bool NoSaveSdPath
		{
			[CompilerGenerated]
			get
			{
				return _003CNoSaveSdPath_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CNoSaveSdPath_003Ek__BackingField = value;
			}
		}

		public bool IsSuccessed
		{
			[CompilerGenerated]
			get
			{
				return _003CIsSuccessed_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CIsSuccessed_003Ek__BackingField = value;
			}
		}

		public int SlicePage
		{
			get
			{
				return slicepage;
			}
			set
			{
				slicepage = value;
			}
		}

		public ProcedureSlice Slice
		{
			[CompilerGenerated]
			get
			{
				return _003CSlice_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CSlice_003Ek__BackingField = value;
			}
		}

		public void Start(string zipFileName = null)
		{
			IsSuccessed = false;
			if (zipFileName == null)
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Multiselect = false;
				openFileDialog.Filter = "eBook (*.sd;*.ipa;*.apa;*.iph;*aph;*.aio)|*.sd;*.ipa;*.apa;*.iph;*aph;*.aio";
				OpenFileDialog ofd = openFileDialog;
				Nullable<bool> flag = ofd.ShowDialog();
				if (flag.GetValueOrDefault() && flag.HasValue)
				{
					RunWorker(ofd.FileName);
				}
			}
			else
			{
				RunWorker(zipFileName);
			}
		}

		private void RunWorker(string zipFileName)
		{
			if (File.Exists(zipFileName))
			{
				if (Singleton.Instance.ProfileService.RecentOpenProfile.Projects.Count >= 8)
				{
					Singleton.Instance.ProfileService.RecentOpenProfile.Projects.RemoveAt(0);
				}
				Singleton.Instance.ProfileService.RecentOpenProfile.Projects.Add(zipFileName);
				Singleton.Instance.ProfileService.SaveToXml();
				Dictionary<string, object> doWorkPara = new Dictionary<string, object>();
				doWorkPara.Add("zipFileName", zipFileName);
				BgWorkerView.RunWorker(new Action<Dictionary<string, object>>(LoadProject), null, doWorkPara);
				if (Path.GetExtension(zipFileName) == ".sd" && !NoSaveSdPath)
				{
					GlobalResource.SaveSdPath = zipFileName;
				}
				if (OpenProjectCompleted != null)
				{
					OpenProjectCompleted(this, EventArgs.Empty);
				}
			}
			else
			{
				MessageBox.Show(GlobalResource.GetString("檔案不存在!"), GlobalResource.MsgTitle, MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		private void LoadProject(Dictionary<string, object> dic)
		{
			BgWorkerView.ReportProgress(GlobalResource.GetString("處理中") + "...");
			string zipFileName = dic["zipFileName"].ToString();
			string tempPath = Path.Combine(FileUtility.GetAndCreateTempFolder(), "eBook");
			string tzip = tempPath + ".zip";
			if (zipFileName.ToLower().Contains(".sd"))
			{
				FileUtility.CopyDirectory(new DirectoryInfo(Path.GetDirectoryName(zipFileName)), new DirectoryInfo(tempPath));
				File.Copy(zipFileName, tzip);
				SevenZipUtility.SevenZipExtractor(tzip, tempPath, GlobalResource.SdPassword);
				FileInfo[] files = new DirectoryInfo(tempPath).GetFiles();
				if (CS_0024_003C_003E9__CachedAnonymousMethodDelegate2 == null)
				{
					CS_0024_003C_003E9__CachedAnonymousMethodDelegate2 = new Func<FileInfo, bool>(_003CLoadProject_003Eb__1);
				}
				string sdXmlPath = Enumerable.First(files, CS_0024_003C_003E9__CachedAnonymousMethodDelegate2).FullName;
				if (string.IsNullOrEmpty(Path.GetExtension(sdXmlPath)))
				{
					GlobalResource.ResoucePath = tempPath + "\\" + Path.GetFileNameWithoutExtension(zipFileName) + "\\";
				}
				else
				{
					GlobalResource.ResoucePath = tempPath + "\\Resource\\";
				}
				DeserializeProject(sdXmlPath);
				IsSuccessed = true;
			}
			else
			{
				File.Copy(zipFileName, tzip);
				SevenZipUtility.SevenZipExtractor(tzip, tempPath);
				GlobalResource.ResoucePath = tempPath + "\\Resource\\";
				GlobalResource.IsSD = false;
				if (File.Exists(tempPath + "\\index.xml"))
				{
					DeserializeProject(tempPath + "\\index.xml");
				}
				else
				{
					DeserializeProject(tempPath + "\\index.dat");
				}
				try
				{
					ProjectController.ResourceSecurity(GlobalResource.ResoucePath, false);
				}
				catch (Exception)
				{
				}
				IsSuccessed = true;
			}
		}

		private void DeserializeProject(string indexXmlPath)
		{
			XElement xmlIndex = XDocument.Load(indexXmlPath).Root;
			DefaultProject proj = new DefaultProject();
			proj.ObjectElement = xmlIndex.Element("Project");
			proj.Deserialize();
			proj.DeserializeThumbnail(xmlIndex);
			if (SlicePage != -1)
			{
				for (int index = proj.ProcedureSliceList.Count - 1; index >= 0; index--)
				{
					if (index != SlicePage)
					{
						proj.ProcedureSliceList.RemoveAt(index);
					}
				}
				Slice = proj.ProcedureSliceList[0];
			}
			else
			{
				GlobalResource.IsNewProject = true;
				Singleton.Instance.DefaultProject = proj;
			}
		}

		[CompilerGenerated]
		private static bool _003CLoadProject_003Eb__1(FileInfo f)
		{
			if (!(f.Extension == ""))
			{
				return f.Name == "index.xml";
			}
			return true;
		}
	}
}
