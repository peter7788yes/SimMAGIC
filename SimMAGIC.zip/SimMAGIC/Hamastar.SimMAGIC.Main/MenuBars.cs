using Hamastar.SimMAGIC.MultiMediaUtility;
using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.SectionDesign;
using Hamastar.SimMAGIC.SectionMetadata;
using Hamastar.SimMAGIC.Utility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Hamastar.SimMAGIC.Main
{
	public class MenuBars
	{
		public static RoutedCommand Option;

		public static RoutedCommand Mterial;

		public static RoutedCommand aboutHelp;

		public static RoutedCommand videoTutorial;

		public static RoutedCommand updater;

		public static RoutedCommand aboutBox;

		public EventHandler MaterialBrowseComplete;

		[CompilerGenerated]
		private MainView _003CmanView_003Ek__BackingField;

		public MainView manView
		{
			[CompilerGenerated]
			get
			{
				return _003CmanView_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CmanView_003Ek__BackingField = value;
			}
		}

		public void AddCommandBindings()
		{
			manView.CommandBindings.Add(new CommandBinding(ApplicationCommands.New, new ExecutedRoutedEventHandler(New_Executed)));
			manView.CommandBindings.Add(new CommandBinding(ApplicationCommands.Open, new ExecutedRoutedEventHandler(Open_Executed)));
			manView.CommandBindings.Add(new CommandBinding(ApplicationCommands.Save, new ExecutedRoutedEventHandler(Save_Executed)));
			manView.CommandBindings.Add(new CommandBinding(ApplicationCommands.SaveAs, new ExecutedRoutedEventHandler(SaveAs_Executed)));
			manView.CommandBindings.Add(new CommandBinding(Option, new ExecutedRoutedEventHandler(Option_Executed)));
			if (IniConfig.DATA.IsUseMaterialLibrary == 1)
			{
				manView.CommandBindings.Add(new CommandBinding(Mterial, new ExecutedRoutedEventHandler(Mterial_Executed)));
			}
			manView.CommandBindings.Add(new CommandBinding(aboutHelp, new ExecutedRoutedEventHandler(aboutHelp_Executed)));
			manView.CommandBindings.Add(new CommandBinding(videoTutorial, new ExecutedRoutedEventHandler(videoTutorial_Executed)));
			manView.CommandBindings.Add(new CommandBinding(aboutBox, new ExecutedRoutedEventHandler(aboutBox_Executed)));
		}

		private void New_Executed(object sender, RoutedEventArgs e)
		{
			if (manView.AskSaveAsProject())
			{
				manView.ResetEBook();
			}
		}

		private void Open_Executed(object sender, RoutedEventArgs e)
		{
			OpenProject openProject = new OpenProject();
			openProject.OpenProjectCompleted = (EventHandler)Delegate.Combine(openProject.OpenProjectCompleted, new EventHandler(OpenProjectCompleted));
			openProject.Start(null);
		}

		private void OpenProjectCompleted(object sender, EventArgs args)
		{
			manView.tabControl.SelectedIndex = 1;
			(manView.tabControl.SelectedContent as DesignTabView).LoadNewProject();
		}

		private void Save_Executed(object sender, RoutedEventArgs e)
		{
			if (Singleton.Instance.DefaultProject != null)
			{
				NotificationCenter.defaultCenter.postNotification(this, "SaveView2Singleton", new Dictionary<string, object>());
				SaveProject saveProject = new SaveProject();
				saveProject.SaveProjectCompleted = (EventHandler)Delegate.Combine(saveProject.SaveProjectCompleted, new EventHandler(SaveComptete));
				saveProject.Start();
			}
		}

		private void SaveComptete(object sender, EventArgs e)
		{
			Singleton.Instance.DefaultProject.ProjectMetadata.Name = sender.ToString();
			MetadataView metadataView = manView.MetadataBackgroundTabView.Root.Child as MetadataView;
			if (metadataView != null)
			{
				metadataView.LoadSingleton();
			}
		}

		private void SaveAs_Executed(object sender, RoutedEventArgs e)
		{
			if (Singleton.Instance.DefaultProject != null)
			{
				NotificationCenter.defaultCenter.postNotification(this, "SaveView2Singleton", new Dictionary<string, object>());
				SaveProject saveProject = new SaveProject();
				saveProject.SaveAs = true;
				saveProject.SaveProjectCompleted = (EventHandler)Delegate.Combine(saveProject.SaveProjectCompleted, new EventHandler(SaveComptete));
				saveProject.Start();
			}
		}

		private void Option_Executed(object sender, RoutedEventArgs e)
		{
			if (Singleton.Instance.DefaultProject != null)
			{
				OptionProfileDialog optionDialog = new OptionProfileDialog();
				optionDialog.ShowDialog();
			}
		}

		private void Mterial_Executed(object sender, RoutedEventArgs e)
		{
			if (Singleton.Instance.DefaultProject == null)
			{
				return;
			}
			using (MaterialWPFDialog MaterialDlg = new MaterialWPFDialog(1000.0, 600.0, MaterialType.All, true))
			{
				MaterialDlg.FileBrowseComplete = (EventHandler)Delegate.Combine(MaterialDlg.FileBrowseComplete, new EventHandler(FileBrowseCompleted));
				Nullable<bool> flag = MaterialDlg.ShowDialog();
				if (flag.GetValueOrDefault() && flag.HasValue)
				{
					string FileType = Path.GetExtension(MaterialDlg.SelectedFilePath).ToLower();
					if (GlobalResource.SupportImage.Contains(FileType))
					{
						PictureObject PicObj = new PictureObject();
						PicObj.XFileName = MaterialDlg.SelectedFilePath;
						Size imgSize = new WPFImageUtility().GetImgSize(PicObj.XFileName);
						PicObj.BoundaryPoint = new Rect(100.0, 100.0, imgSize.Width, imgSize.Height);
						Singleton.Instance.DefaultProject.CurrentSlice.AddWhiteboardObject(PicObj);
					}
					else
					{
						AdditionalFileObject Addobj = new AdditionalFileObject();
						Addobj.PathFileName = MaterialDlg.SelectedFilePath;
						Addobj.BoundaryPoint = new Rect(100.0, 100.0, 150.0, 150.0);
						Singleton.Instance.DefaultProject.CurrentSlice.AddWhiteboardObject(Addobj);
					}
					NotificationCenter.defaultCenter.postNotification(this, "ReloadCurrentSlice", new Dictionary<string, object>());
				}
			}
		}

		private void FileBrowseCompleted(object sender, EventArgs e)
		{
			FileEventArgs args = e as FileEventArgs;
			if (MaterialBrowseComplete != null)
			{
				MaterialBrowseComplete(this, args);
			}
		}

		public void AddGlobalLangContent()
		{
			manView.GlobalLangSelector.SubmenuOpened += new RoutedEventHandler(GlobalLangSelector_SubmenuOpened);
			manView.GlobalLangSelector.Click += new RoutedEventHandler(GlobalLangSelector_Click);
			manView.GlobalLangSelector.Items.Clear();
			foreach (CultureInfo culture in CulturesHelper.SupportedCultures)
			{
				MenuItem menuItem = new MenuItem();
				menuItem.Header = culture.NativeName;
				menuItem.Tag = culture.Name;
				menuItem.IsCheckable = true;
				manView.GlobalLangSelector.Items.Add(menuItem);
			}
		}

		private void GlobalLangSelector_SubmenuOpened(object sender, RoutedEventArgs e)
		{
			foreach (MenuItem item in (IEnumerable)(sender as MenuItem).Items)
			{
				item.IsChecked = false;
				if (item.Header.ToString() == CulturesHelper.CurrentCulture.NativeName)
				{
					item.IsChecked = true;
				}
			}
		}

		private void GlobalLangSelector_Click(object sender, RoutedEventArgs e)
		{
			string lang = ((MenuItem)e.OriginalSource).Tag.ToString();
			CulturesHelper.ChangeCulture(new CultureInfo(lang));
		}

		private void aboutHelp_Executed(object sender, EventArgs e)
		{
			Process p = new Process();
			string helpFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "AboutHelp", GlobalResource.GetString("操作導引.pdf"));
			p.StartInfo.FileName = helpFilePath;
			p.Start();
		}

		private void videoTutorial_Executed(object sender, EventArgs e)
		{
			string videoUrl = string.Format(GlobalResource.VideoTutorial, GlobalResource.GetString("視訊教學Url語系"));
			Process.Start(videoUrl);
		}

		private void updater_Executed(object sender, EventArgs e)
		{
			Process.Start(AppDomain.CurrentDomain.BaseDirectory + "\\Tools.Hamastar.Updater.exe");
		}

		private void aboutBox_Executed(object sender, EventArgs e)
		{
			SimMAGICAboutDialog dlg = new SimMAGICAboutDialog();
			dlg.ShowDialog();
		}

		static MenuBars()
		{
			Type typeFromHandle = typeof(MenuBars);
			InputGestureCollection inputGestureCollection = new InputGestureCollection();
			inputGestureCollection.Add(new KeyGesture(Key.L, ModifierKeys.Control));
			Option = new RoutedCommand("Option", typeFromHandle, inputGestureCollection);
			Type typeFromHandle2 = typeof(MenuBars);
			InputGestureCollection inputGestureCollection2 = new InputGestureCollection();
			inputGestureCollection2.Add(new KeyGesture(Key.T, ModifierKeys.Control));
			Mterial = new RoutedCommand("Mterial", typeFromHandle2, inputGestureCollection2);
			Type typeFromHandle3 = typeof(MenuBars);
			InputGestureCollection inputGestureCollection3 = new InputGestureCollection();
			inputGestureCollection3.Add(new KeyGesture(Key.H, ModifierKeys.Control));
			aboutHelp = new RoutedCommand("aboutHelp", typeFromHandle3, inputGestureCollection3);
			Type typeFromHandle4 = typeof(MenuBars);
			InputGestureCollection inputGestureCollection4 = new InputGestureCollection();
			inputGestureCollection4.Add(new KeyGesture(Key.R, ModifierKeys.Control));
			videoTutorial = new RoutedCommand("videoTutorial", typeFromHandle4, inputGestureCollection4);
			Type typeFromHandle5 = typeof(MenuBars);
			InputGestureCollection inputGestureCollection5 = new InputGestureCollection();
			inputGestureCollection5.Add(new KeyGesture(Key.W, ModifierKeys.Control));
			updater = new RoutedCommand("updater", typeFromHandle5, inputGestureCollection5);
			Type typeFromHandle6 = typeof(MenuBars);
			InputGestureCollection inputGestureCollection6 = new InputGestureCollection();
			inputGestureCollection6.Add(new KeyGesture(Key.B, ModifierKeys.Control));
			aboutBox = new RoutedCommand("aboutBox", typeFromHandle6, inputGestureCollection6);
		}
	}
}
