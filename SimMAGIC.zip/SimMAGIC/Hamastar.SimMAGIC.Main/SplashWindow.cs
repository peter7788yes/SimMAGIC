using Hamastar.IO;
using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.Utility;
using Hamastar.SimMAGIC.Utility.BackgroundLoading;
using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Hamastar.SimMAGIC.Main
{
	public class SplashWindow : Window, IComponentConnector
	{
		private RegistryKey GlobalResourcesKey;

		internal Grid BGrid;

		internal TextBlock ProductName;

		private bool _contentLoaded;

		public SplashWindow()
		{
			InitializeComponent();
			Singleton.Instance.ProfileService = new ProfileService();
			Singleton.Instance.ProfileService.LoadFromXml();
			new CulturesHelper();
			using (GlobalResourcesKey = Registry.CurrentUser.OpenSubKey(string.Format("Software\\Hamastar\\{0}\\GlobalResources\\", IniConfig.DATA.ProductVersion)))
			{
				if (GlobalResourcesKey != null)
				{
					object cultureInfo = GlobalResourcesKey.GetValue("Culture");
					if (cultureInfo != null)
					{
						CultureInfo culture2 = new CultureInfo(cultureInfo.ToString());
						CulturesHelper.ChangeCulture(culture2);
					}
				}
				else
				{
					CultureInfo culture = new CultureInfo("zh-Hant");
					try
					{
						culture = new CultureInfo(Singleton.Instance.ProfileService.Lang);
					}
					catch
					{
					}
					CulturesHelper.ChangeCulture(culture);
				}
			}
			base.Loaded += new RoutedEventHandler(SplashWindow_Loaded);
		}

		private void SplashWindow_Loaded(object sender, RoutedEventArgs e)
		{
			Uri uri = new Uri(string.Format("pack://application:,,,/SimMAGIC;component/Images/{0}/Splash.png", GlobalResource.MsgTitle));
			BGrid.Background = new ImageBrush(new BitmapImage(uri));
			ProductName.Text = GlobalResource.GetString("互動式多媒體電子書編輯軟體");
		}

		public void SystemInit()
		{
			LogUtility.SetLogFilePath(IniConfig.DATA.ProductVersion);
			if (!Directory.Exists(GlobalResource.HamastarTempPath))
			{
				Directory.CreateDirectory(GlobalResource.HamastarTempPath);
			}
			Application.Current.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(Current_DispatcherUnhandledException);
			Application.Current.Exit += new ExitEventHandler(App_Exit);
			RunExe();
			RunRegedit();
		}

		private void RunRegedit()
		{
			RegistryKey rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Wow6432Node\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION");
			if (rk == null || rk.GetValue("Hamastar.SimMAGIC.Main.exe") == null)
			{
				Process regIE11 = new Process();
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				processStartInfo.FileName = AppDomain.CurrentDomain.BaseDirectory + "regIE11.bat";
				processStartInfo.CreateNoWindow = true;
				processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				processStartInfo.Verb = "runas";
				ProcessStartInfo proInfo = regIE11.StartInfo = processStartInfo;
				regIE11.Start();
				regIE11.WaitForExit();
			}
		}

		private void App_Exit(object sender, ExitEventArgs e)
		{
			Singleton.Instance.ProfileService.SaveToXml();
			FileUtility.ClearTempFolder();
			FileUtility.ClearDeleteList();
			if (Enumerable.Any(Process.GetProcessesByName(Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().Location))))
			{
				return;
			}
			DirectoryInfo tempDir = new DirectoryInfo(GlobalResource.HamastarTempPath);
			List<string> ignoreData = new List<string>();
			ignoreData.Add("ProfileService.xml");
			ignoreData.Add("CustomMotherboard5.0");
			ignoreData.Add("Material");
			ignoreData.Add("MaterialForUserAdd");
			ignoreData.Add("Log");
			DirectoryInfo[] directories = tempDir.GetDirectories();
			foreach (DirectoryInfo dir in directories)
			{
				if (!ignoreData.Contains(dir.Name))
				{
					FileUtility.ForceDeleteDirectory(dir.FullName);
				}
			}
			FileInfo[] files = tempDir.GetFiles();
			foreach (FileInfo file in files)
			{
				if (!ignoreData.Contains(file.Name))
				{
					file.Delete();
				}
			}
		}

		private void Current_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			LogUtility.WriteLog(e.Exception, true);
			BgWorkerView.CancelWorker();
			e.Handled = true;
		}

		private void RunExe()
		{
			string path = AppDomain.CurrentDomain.BaseDirectory;
			if (!Directory.Exists(Path.Combine(path, "BookTemplates")) && File.Exists(Path.Combine(path, "BookTemplates.exe")))
			{
				Process installSL3 = new Process();
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				processStartInfo.FileName = path + "\\BookTemplates.exe";
				processStartInfo.Arguments = "\"" + path + "\"";
				processStartInfo.UseShellExecute = false;
				processStartInfo.CreateNoWindow = true;
				ProcessStartInfo installSLInfo3 = installSL3.StartInfo = processStartInfo;
				installSL3.Start();
				installSL3.WaitForExit();
			}
			if (!Directory.Exists(Path.Combine(path, "Epub3")) && File.Exists(Path.Combine(path, "Epub3.exe")))
			{
				Process installSL2 = new Process();
				ProcessStartInfo processStartInfo3 = new ProcessStartInfo();
				processStartInfo3.FileName = path + "\\Epub3.exe";
				processStartInfo3.Arguments = "\"" + path + "\"";
				processStartInfo3.UseShellExecute = false;
				processStartInfo3.CreateNoWindow = true;
				ProcessStartInfo installSLInfo2 = installSL2.StartInfo = processStartInfo3;
				installSL2.Start();
				installSL2.WaitForExit();
			}
			if (!Directory.Exists(Path.Combine(path, "HTML5")) && File.Exists(Path.Combine(path, "HTML5.exe")))
			{
				Process installSL = new Process();
				ProcessStartInfo processStartInfo5 = new ProcessStartInfo();
				processStartInfo5.FileName = path + "\\HTML5.exe";
				processStartInfo5.Arguments = "\"" + path + "\"";
				processStartInfo5.UseShellExecute = false;
				processStartInfo5.CreateNoWindow = true;
				ProcessStartInfo installSLInfo = installSL.StartInfo = processStartInfo5;
				installSL.Start();
				installSL.WaitForExit();
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/splashwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				BGrid = (Grid)target;
				break;
			case 2:
				ProductName = (TextBlock)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
