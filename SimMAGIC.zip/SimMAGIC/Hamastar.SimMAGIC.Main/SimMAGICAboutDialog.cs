using Hamastar.SimMAGIC.Security;
using Hamastar.SimMAGIC.Utility;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;

namespace Hamastar.SimMAGIC.Main
{
	public class SimMAGICAboutDialog : Window, IComponentConnector
	{
		private const string Key = "Hamast@r";

		private const string Iv = "Hamast@r";

		internal TextBox VersionTxt;

		internal TextBox Version;

		internal TextBox SerialTxt;

		internal TextBox Serial;

		internal TextBox CnTxt;

		internal TextBox Cn;

		internal RichTextBox RtfTxt;

		private bool _contentLoaded;

		public SimMAGICAboutDialog()
		{
			InitializeComponent();
			Initial();
		}

		private static void Decrypt(string input, string output)
		{
			Des.createFile(Des.getDeCodeing(input, "Hamast@r", "Hamast@r"), output);
		}

		public void Initial()
		{
			string tempPath = Path.GetTempPath();
			File.Copy(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Copyright.rtf"), Path.Combine(tempPath, "@@.rtf"), true);
			try
			{
				Decrypt(Path.Combine(tempPath, "@@.rtf"), Path.Combine(tempPath, "Copyright.rtf"));
				using (FileStream stream = new FileStream(Path.Combine(tempPath, "Copyright.rtf"), FileMode.OpenOrCreate))
				{
					RtfTxt.Selection.Load(stream, DataFormats.Rtf);
				}
				TextRange r = new TextRange(RtfTxt.Selection.Start, RtfTxt.Selection.End);
				r.ApplyPropertyValue(TextElement.FontSizeProperty, "16");
			}
			catch (Exception ex)
			{
				LogUtility.WriteLog(ex, true);
			}
			base.Title = GlobalResource.GetString("關於") + " " + GlobalResource.MsgTitle;
			VersionTxt.Text = GlobalResource.GetString("版本") + ": ";
			Version.Text = GlobalResource.GetEditorVersion() + " " + IniConfig.DATA.ProductVersion;
			SerialTxt.Text = GlobalResource.GetString("序號") + ": ";
			Serial.Text = GlobalResource.Sn;
			CnTxt.Text = GlobalResource.GetString("機碼") + ": ";
			Cn.Text = GlobalResource.ComputerNum;
		}

		private void Version_OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ClickCount > 2)
			{
				GlobalResource.IsExamProcedureSlice = !GlobalResource.IsExamProcedureSlice;
				MessageBox.Show("切換一頁多題組功能!");
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/usercontrol/simmagicaboutdialog.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				VersionTxt = (TextBox)target;
				VersionTxt.PreviewMouseDown += new MouseButtonEventHandler(Version_OnPreviewMouseDown);
				break;
			case 2:
				Version = (TextBox)target;
				break;
			case 3:
				SerialTxt = (TextBox)target;
				break;
			case 4:
				Serial = (TextBox)target;
				break;
			case 5:
				CnTxt = (TextBox)target;
				break;
			case 6:
				Cn = (TextBox)target;
				break;
			case 7:
				RtfTxt = (RichTextBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
