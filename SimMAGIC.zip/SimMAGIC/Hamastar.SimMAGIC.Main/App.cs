using Hamastar.SimMAGIC.Utility;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace Hamastar.SimMAGIC.Main
{
	public class App : Application
	{
		private bool _contentLoaded;

		private void App_OnStartup(object sender, StartupEventArgs e)
		{
			Application.Current.Resources["AppIcon"] = GlobalResource.AppIcon;
			ResourceDictionary resources = Application.Current.Resources;
			TextBlock textBlock = new TextBlock();
			textBlock.Text = GlobalResource.MsgTitle;
			resources["AppTitle"] = textBlock;
			SplashWindow splash = new SplashWindow();
			splash.Show();
			splash.SystemInit();
			MainWindow main = new MainWindow();
			splash.Close();
			main.Show();
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				base.Startup += new StartupEventHandler(App_OnStartup);
				Uri resourceLocater = new Uri("/SimMAGIC;component/app.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[STAThread]
		public static void Main()
		{
			App app = new App();
			app.InitializeComponent();
			app.Run();
		}
	}
}
