using Hamastar.IO;
using Hamastar.SimMAGIC.Project;
using Hamastar.SimMAGIC.SectionDesign;
using Hamastar.SimMAGIC.SectionExport;
using Hamastar.SimMAGIC.SectionMetadata;
using Hamastar.SimMAGIC.SectionPreview;
using Hamastar.SimMAGIC.Utility;
using Hamastar.SimMAGIC.Utility.BackgroundLoading;
using Hamastar.Verification;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Hamastar.SimMAGIC.Main
{
	public class MainView : UserControl, IComponentConnector
	{
		private MultiVerification multiVerification = new MultiVerification();

		private string exportDirectory;

		private WebBrowser webBrowserHtml5;

		internal Menu Menu;

		internal MenuItem FileMenuItem;

		internal MenuItem GlobalLangSelector;

		internal MenuItem Mterial;

		internal Grid RightTopLogo;

		internal Image RightTopLogoImg;

		internal TextBlock EducationLevelTxt;

		internal TextBlock VersionTypeTxt;

		internal TabControl tabControl;

		internal TabItem MetadataTabItem;

		internal BackgroundTabView MetadataBackgroundTabView;

		internal TabItem DesignTabItem;

		internal DesignTabView DesignTabView;

		internal TabItem PreviewTabItem;

		internal PreviewView PreviewViewTabItem;

		internal TabItem ExportTabItem;

		internal BackgroundTabView ExportBackgroundTabView;

		private bool _contentLoaded;

		[CompilerGenerated]
		private ProcedureSlice _003CSlice_003Ek__BackingField;

		[CompilerGenerated]
		private static EventHandler CS_0024_003C_003E9__CachedAnonymousMethodDelegate1;

		private ProcedureSlice Slice
		{
			[CompilerGenerated]
			get
			{
				return _003CSlice_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CSlice_003Ek__BackingField = value;
			}
		}

		public MainView()
		{
			InitializeComponent();
			Init();
			base.Loaded += new RoutedEventHandler(MainView_Loaded);
		}

		private void MainView_Loaded(object sender, RoutedEventArgs e)
		{
			TemplateHelper templateHelper = new TemplateHelper();
			TabPanel tabPanel = templateHelper.FindDescendant<TabPanel>(tabControl);
			tabPanel.Background = Brushes.Transparent;
			tabPanel.MouseLeftButtonDown += new MouseButtonEventHandler(tabPanel_MouseLeftButtonDown);
			multiVerification.Url = IniConfig.DATA.Url;
			multiVerification.Verification();
			MultiVerification obj = multiVerification;
			EventHandler verificationCompleted = obj.VerificationCompleted;
			if (CS_0024_003C_003E9__CachedAnonymousMethodDelegate1 == null)
			{
				CS_0024_003C_003E9__CachedAnonymousMethodDelegate1 = new EventHandler(_003CMainView_Loaded_003Eb__0);
			}
			obj.VerificationCompleted = (EventHandler)Delegate.Combine(verificationCompleted, CS_0024_003C_003E9__CachedAnonymousMethodDelegate1);
			SetViewBySingleton();
			Mterial.Visibility = ((IniConfig.DATA.IsUseMaterialLibrary != 1) ? Visibility.Collapsed : Visibility.Visible);
			GlobalLangSelector.Visibility = ((IniConfig.DATA.IsLanguageSet != 1) ? Visibility.Collapsed : Visibility.Visible);
		}

		private void tabPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (sender is TabItem)
			{
				e.Handled = true;
			}
			else if (e.ClickCount == 2)
			{
				CloseMenuItem_OnClick(null, null);
			}
		}

		private void Init()
		{
			ExportBackgroundTabView.Root.Child = new ExportView();
			MetadataView metadataView = new MetadataView();
			metadataView.NewProjectEvent = (EventHandler)Delegate.Combine(metadataView.NewProjectEvent, new EventHandler(NewProjectEvent));
			MetadataBackgroundTabView.Root.Child = metadataView;
			MenuBars menubars = new MenuBars();
			menubars.manView = this;
			menubars.AddCommandBindings();
			menubars.AddGlobalLangContent();
			Uri uri = new Uri(string.Format("pack://application:,,,/SimMAGIC;component/Images/{0}/projectTabControl.RightTopLogoImageBlueTw.png", GlobalResource.MsgTitle));
			RightTopLogoImg.Source = new BitmapImage(uri);
			EducationLevelTxt.Text = GlobalResource.GetEducationLevel();
			VersionTypeTxt.Text = GlobalResource.GetVersionType();
			VersionTypeColor();
			NotificationCenter.defaultCenter.registObserver(this, new Action<object, Dictionary<string, object>>(LoadProject), "LoadProject");
		}

		private void VersionTypeColor()
		{
			BrushConverter BrushConverter = new BrushConverter();
			switch (IniConfig.DATA.VersionType)
			{
			case 1:
				VersionTypeTxt.Foreground = (Brush)BrushConverter.ConvertFrom("#FF1600BB");
				break;
			case 2:
				VersionTypeTxt.Foreground = (Brush)BrushConverter.ConvertFrom("#FFF08519");
				break;
			case 3:
				VersionTypeTxt.Foreground = (Brush)BrushConverter.ConvertFrom("#FFE40082");
				break;
			}
		}

		private void LoadProject(object o, Dictionary<string, object> dictionary)
		{
			OpenProject openProject = new OpenProject();
			openProject.SlicePage = (int)dictionary["page"];
			openProject.OpenProjectCompleted = (EventHandler)Delegate.Combine(openProject.OpenProjectCompleted, new EventHandler(OpenProjectCompleted));
			openProject.Start(dictionary["templateEDPath"].ToString());
		}

		private void OpenProjectCompleted(object sender, EventArgs args)
		{
			Slice = (sender as OpenProject).Slice;
			(tabControl.SelectedContent as DesignTabView).NewSlice(Slice);
		}

		private void CloseMenuItem_OnClick(object sender, RoutedEventArgs e)
		{
			MainWindow mWindow = base.Parent as MainWindow;
			if (mWindow != null)
			{
				ResetEBook();
				mWindow.SetStartView();
			}
		}

		public void ResetEBook()
		{
			DesignTabView.DisposeDesignerViewItems();
			if (Singleton.Instance.DefaultProject != null)
			{
				Singleton.Instance.DefaultProject.ProcedureSliceList.Clear();
				Singleton.Instance.DefaultProject = null;
			}
			SetViewBySingleton();
		}

		private void SetViewBySingleton()
		{
			if (Singleton.Instance.DefaultProject == null)
			{
				DesignTabItem.Visibility = Visibility.Hidden;
				PreviewTabItem.Visibility = Visibility.Hidden;
				ExportTabItem.Visibility = Visibility.Hidden;
				tabControl.SelectedIndex = 0;
				MetadataView metadataView = MetadataBackgroundTabView.Root.Child as MetadataView;
				if (metadataView != null)
				{
					metadataView.MetadataTab.SelectedIndex = 0;
					metadataView.LoadSingleton();
				}
			}
			else
			{
				DesignTabItem.Visibility = Visibility.Visible;
				PreviewTabItem.Visibility = Visibility.Visible;
				ExportTabItem.Visibility = Visibility.Visible;
			}
		}

		public void NewProjectEvent(object sender, EventArgs eventArgs)
		{
			NewBookInfoEventArgs motherboard = eventArgs as NewBookInfoEventArgs;
			if (motherboard != null && AskSaveAsProject())
			{
				if (Singleton.Instance.DefaultProject != null)
				{
					motherboard.Name = "";
					motherboard.Author = "";
					motherboard.Introduction = "";
					motherboard.Purpose = "";
				}
				NewSingletonProject(motherboard);
				DesignTabView.DisposeDesignerViewItems();
				tabControl.SelectedIndex = 1;
			}
		}

		public bool AskSaveAsProject()
		{
			if (Singleton.Instance.DefaultProject != null)
			{
				switch (MessageBox.Show(GlobalResource.GetString("目前教材已被修改是否要存檔?"), GlobalResource.MsgTitle, MessageBoxButton.YesNoCancel, MessageBoxImage.Asterisk))
				{
				case MessageBoxResult.Cancel:
					return false;
				case MessageBoxResult.Yes:
				{
					SaveProject saveProject = new SaveProject();
					saveProject.Start();
					break;
				}
				}
			}
			return true;
		}

		private void Selector_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (GlobalResource.CurrentShowMode == (ShowMode)tabControl.SelectedIndex)
			{
				return;
			}
			if (GlobalResource.CurrentShowMode == ShowMode.Metadata)
			{
				DesignTabItem.Visibility = Visibility.Visible;
				PreviewTabItem.Visibility = Visibility.Visible;
				ExportTabItem.Visibility = Visibility.Visible;
			}
			if (GlobalResource.CurrentShowMode == ShowMode.Design)
			{
				if (Singleton.Instance.DefaultProject != null)
				{
					NotificationCenter.defaultCenter.postNotification(this, "SaveView2Singleton", new Dictionary<string, object>());
				}
			}
			else if (GlobalResource.CurrentShowMode == ShowMode.Preview)
			{
				PreviewViewTabItem.Dispose();
			}
			if (tabControl.SelectedIndex != 0 && tabControl.SelectedIndex == 2 && Singleton.Instance.DefaultProject != null)
			{
				Singleton.Instance.DefaultProject.SerializeThumbnail();
			}
			GlobalResource.CurrentShowMode = (ShowMode)tabControl.SelectedIndex;
		}

		private void StartPreview()
		{
			ExportView exportView = ExportBackgroundTabView.Root.Child as ExportView;
			if (exportView != null)
			{
				Dictionary<string, object> dic = new Dictionary<string, object>();
				exportDirectory = FileUtility.GetAndCreateTempFolder();
				dic.Add("ExportDirectory", exportDirectory);
				dic.Add("IsSuccessed", false);
				BgWorkerView.RunWorker(new Action<Dictionary<string, object>>(exportView.PreviewByExportHtml5), new Action<object>(BrowserNavigate), dic);
			}
		}

		private void BrowserNavigate(object e)
		{
			if ((e as RunWorkerCompletedEventArgs).Cancelled)
			{
				tabControl.SelectedIndex = 1;
				return;
			}
			if (webBrowserHtml5 == null)
			{
				webBrowserHtml5 = new WebBrowser();
			}
			webBrowserHtml5.Navigate(new Uri(Path.Combine(exportDirectory, "Html5", "index.html")));
			PreviewTabItem.Content = webBrowserHtml5;
		}

		private void NewSingletonProject(NewBookInfoEventArgs newBookInfoInfo)
		{
			DefaultProject project = new DefaultProject();
			project.ProjectMetadata.Name = newBookInfoInfo.Name;
			project.ProjectMetadata.Author = newBookInfoInfo.Author;
			project.ProjectMetadata.Purpose = newBookInfoInfo.Purpose;
			project.ProjectMetadata.Introduction = newBookInfoInfo.Introduction;
			project.DefaultMotherboard.Bounds = new Rect(2.0, 2.0, newBookInfoInfo.Size.Width, newBookInfoInfo.Size.Height);
			project.DefaultMotherboard.InitialTargetSize = project.DefaultMotherboard.Bounds.Size;
			ProcedureSlice ps = new ProcedureSlice();
			ps.Motherboard.Bounds = project.DefaultMotherboard.Bounds;
			ps.Motherboard.InitialTargetSize = project.DefaultMotherboard.InitialTargetSize;
			ps.Motherboard.ImageSectionObject.ImageFileName = newBookInfoInfo.ImgFilePath;
			GlobalResource.TemplateBg = newBookInfoInfo.ImgFilePath;
			project.AddProcedureSlice(ps);
			GlobalResource.IsNewProject = true;
			GlobalResource.DefaultMotherboardSize = new Size(0.0, 0.0);
			Singleton.Instance.DefaultProject = project;
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocater = new Uri("/SimMAGIC;component/usercontrol/mainview.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocater);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				Menu = (Menu)target;
				break;
			case 2:
				FileMenuItem = (MenuItem)target;
				break;
			case 3:
				((MenuItem)target).Click += new RoutedEventHandler(CloseMenuItem_OnClick);
				break;
			case 4:
				GlobalLangSelector = (MenuItem)target;
				break;
			case 5:
				Mterial = (MenuItem)target;
				break;
			case 6:
				RightTopLogo = (Grid)target;
				break;
			case 7:
				RightTopLogoImg = (Image)target;
				break;
			case 8:
				EducationLevelTxt = (TextBlock)target;
				break;
			case 9:
				VersionTypeTxt = (TextBlock)target;
				break;
			case 10:
				tabControl = (TabControl)target;
				tabControl.SelectionChanged += new SelectionChangedEventHandler(Selector_OnSelectionChanged);
				break;
			case 11:
				MetadataTabItem = (TabItem)target;
				MetadataTabItem.MouseLeftButtonDown += new MouseButtonEventHandler(tabPanel_MouseLeftButtonDown);
				break;
			case 12:
				MetadataBackgroundTabView = (BackgroundTabView)target;
				break;
			case 13:
				DesignTabItem = (TabItem)target;
				DesignTabItem.MouseLeftButtonDown += new MouseButtonEventHandler(tabPanel_MouseLeftButtonDown);
				break;
			case 14:
				DesignTabView = (DesignTabView)target;
				break;
			case 15:
				PreviewTabItem = (TabItem)target;
				PreviewTabItem.MouseLeftButtonDown += new MouseButtonEventHandler(tabPanel_MouseLeftButtonDown);
				break;
			case 16:
				PreviewViewTabItem = (PreviewView)target;
				break;
			case 17:
				ExportTabItem = (TabItem)target;
				ExportTabItem.MouseLeftButtonDown += new MouseButtonEventHandler(tabPanel_MouseLeftButtonDown);
				break;
			case 18:
				ExportBackgroundTabView = (BackgroundTabView)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[CompilerGenerated]
		private static void _003CMainView_Loaded_003Eb__0(object o, EventArgs args)
		{
			Dictionary<string, string> dic = o as Dictionary<string, string>;
			GlobalResource.Sn = dic["Sn"];
			GlobalResource.ComputerNum = dic["ComputerNum"];
		}
	}
}
